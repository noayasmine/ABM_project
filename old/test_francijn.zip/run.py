from .test import Network



server.launch(open_browser=True)
