import math
from enum import Enum

import mesa
import networkx as nx
import random
import numpy as np

class Network(mesa.Model):
    """
    A model with some number of agents
    """

    def __init__(
        self,
        num_agents,
        avg_node_degree,
        network
    ):
        
        super().__init__()
        self.num_nodes = num_agents
        self.G = network
        self.grid = mesa.space.NetworkGrid(self.G)
        self.schedule = mesa.time.RandomActivation(self)

        self.n_nodes = num_agents

        self.datacollector = mesa.DataCollector(
            {
                "n_edges": "n_edges"
            }
        )

        # Create agents
        for i, node in enumerate(self.G.nodes()):
            a = Agent(
                i,
                self.G
            )
            self.schedule.add(a)
            # Add the agent to the node
            self.grid.place_agent(a, node)

        # for server
        self.running = True

    def event_happens(self, chance):
        random_number = random.randint(1, chance)
    # Check if the number is 1
        if random_number == 1:
            return True
        else:
            return False

    def diminish_network(self):

        N = self.n_nodes

        for i in self.G.nodes():
            # check if it still has edges
            if len(self.G.edges(i)) != 0:
                # with 1/N (where N is the components still connected) the node loses an edge
                if self.event_happens(N):
                    # select random edge
                    edge = list(self.G.edges(i))[random.choice(range(len(self.G.edges(i))))]
                    # remove that edge
                    # notice that it is only "one way" that is removed.
                    self.G.remove_edge(edge[0], edge[1])
            

    def collect_data(self):
        # if there are no more edges anymore the network is "dissolved"
        self.n_edges = self.G.number_of_edges()

         # collect data
        self.datacollector.collect(self)


    def step(self):
        self.diminish_network()
        self.collect_data()

        self.schedule.step()

    def run_model(self, n):
        for i in range(n):
            self.step()

class Agent(mesa.Agent):

    def __init__(
    self,
    unique_id,
    model
    ):
            
        super().__init__(unique_id, model)
        self.unique_id = unique_id
        self.model = model
        self.delta = random.choice([0, 1])
        

    def influencer_actions(self):
        i_actions = []


    def follower_actions(self):
        f_actions = []

    def is_influencer(self):
        # if agent their in degree > avg in degree then they are influencer 
        avg_degree = np.mean([d for n, d in self.model.in_degree()])

        if self.model.in_degree(self.unique_id) > avg_degree:
            return True
        else:
            return False

    def step(self):
        # what agent does if they are influencer
        if self.is_influencer(self):
            self.influencer_actions(self)
        # what agent does if they are follower
        else:
            self.follower_actions(self)
            

        


        


